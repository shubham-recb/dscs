
function show()
{

    
    var dsc1=document.getElementById("dsc1");
    var dsc2=document.getElementById("dsc2");
    dsc1.style.display="block";
    dsc2.style.display="block";
    //dsc.style.transform="rotateY(-180deg)";
}
function hide()
{
    var dsc1=document.getElementById("dsc1");
    var dsc2=document.getElementById("dsc2");
    dsc1.style.display="none";
    dsc2.style.display="none";
}
function show1()
{

    
    var rec1=document.getElementById("rec1");
    var rec2=document.getElementById("rec2");
    rec1.style.display="block";
    rec2.style.display="block";
    //dsc.style.transform="rotateY(-180deg)";
}
function hide1()
{
				var rec1=document.getElementById("rec1");
				var rec2=document.getElementById("rec2");
				rec1.style.display="none";
				rec2.style.display="none";
}
